<?php
/**
 * Plugin Name: Belajar CRUD
 * Plugin URI: #
 * Version: 1.0
 * Author: Yoga Pratama
 * Author URI: https://yogapratama.dev
 * Description: Belajar CRUD
 * License: GPL2
 */

if ( ! function_exists( 'crm' ) ) {
	function crm() {
		// Do something here
  }
}

class YPSimpleCRM {
     
	/**
	 * Constructor. Called when plugin is initialised
	 */
	function __construct() {
		add_action( 'init', array( $this, 'register_custom_post_type' ) );
		add_action( 'add_meta_boxes', array( $this, 'register_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'save_meta_boxes' ) );
		add_filter( 'manage_edit-contact_columns', array( $this, 'add_table_columns' ) );
		add_action( 'manage_contact_posts_custom_column', array( $this, 'output_table_columns_data'), 10, 2 );
	}

	/**
	 * Registers a Custom Post Type called contact
	 */
	function register_custom_post_type() {
	  register_post_type( 'contact', array(
	    'labels' => array(
	        'name'               => _x( 'Contacts', 'post type general name', 'yp-crm' ),
	        'singular_name'      => _x( 'Contact', 'post type singular name', 'yp-crm' ),
	        'menu_name'          => _x( 'Contacts', 'admin menu', 'yp-crm' ),
	        'name_admin_bar'     => _x( 'Contact', 'add new on admin bar', 'yp-crm' ),
	        'add_new'            => _x( 'Add New', 'contact', 'yp-crm' ),
	        'add_new_item'       => __( 'Add New Contact', 'yp-crm' ),
	        'new_item'           => __( 'New Contact', 'yp-crm' ),
	        'edit_item'          => __( 'Edit Contact', 'yp-crm' ),
	        'view_item'          => __( 'View Contact', 'yp-crm' ),
	        'all_items'          => __( 'All Contacts', 'yp-crm' ),
	        'search_items'       => __( 'Search Contacts', 'yp-crm' ),
	        'parent_item_colon'  => __( 'Parent Contacts:', 'yp-crm' ),
	        'not_found'          => __( 'No conttacts found.', 'yp-crm' ),
	        'not_found_in_trash' => __( 'No contacts found in Trash.', 'yp-crm' ),
	    ),
	       
      // Frontend
      'has_archive'        => false,
      'public'             => false,
      'publicly_queryable' => false,
       
      // Admin
      'capabilities' => array(
	      'edit_others_posts'     => 'edit_others_contacts',
	      'delete_others_posts'   => 'delete_others_contacts',
	      'delete_private_posts'  => 'delete_private_contacts',
	      'edit_private_posts'    => 'edit_private_contacts',
	      'read_private_posts'    => 'read_private_contacts',
	      'edit_published_posts'  => 'edit_published_contacts',
	      'publish_posts'         => 'publish_contacts',
	      'delete_published_posts'=> 'delete_published_contacts',
	      'edit_posts'            => 'edit_contacts'   ,
	      'delete_posts'          => 'delete_contacts',
	      'edit_post'             => 'edit_contact',
	      'read_post'             => 'read_contact',
	      'delete_post'           => 'delete_contact',
      ),
      'map_meta_cap' => true,
      'menu_icon'     => 'dashicons-businessman',
      'menu_position' => 10,
      'query_var'     => true,
      'show_in_menu'  => true,
      'show_ui'       => true,
      'supports'      => array(
          'title',
          'author',
      ),
	  ) );    
	}

	/**
	* User role
	*/
	function plugin_activation() {
	     
    // Custom user role
    $customCaps = array(
      'edit_others_contacts'          => true,
      'delete_others_contacts'        => true,
      'delete_private_contacts'       => true,
      'edit_private_contacts'         => true,
      'read_private_contacts'         => true,
      'edit_published_contacts'       => true,
      'publish_contacts'          => true,
      'delete_published_contacts'     => true,
      'edit_contacts'             => true,
      'delete_contacts'           => true,
      'edit_contact'              => true,
      'read_contact'              => true,
      'delete_contact'            => true,
      'read'                  => true,
    );
	     
    // Register custom role
    add_role( 'crm', __( 'CRM', 'yp-crm'), $customCaps );
	     
	}

	/**
	* Deactivation hook to unregister our existing Contacts Role
	*/
	function plugin_deactivation() {

		remove_role( 'crm' );
	     
	}

	/**
	* Outputs our Contact custom field data, based on the column requested
	*
	* @param string $columnName Column Key Name
	* @param int $post_id Post ID
	*/
	function output_table_columns_data( $columnName, $post_id ) {
	    echo get_post_meta( $post_id, $columnName, true );    
	}

	/**
	* Adds table columns to the Contacts WP_List_Table
	*
	* @param array $columns Existing Columns
	* @return array New Columns
	*/
	function add_table_columns( $columns ) {
	 
	  $columns['_contact_email'] = __( 'Email Address', 'yp-crm' );
	   
	  return $columns;
	     
	}

	/**
	* Contact Details
	*/
	function register_meta_boxes() {
		add_meta_box( 'contact-details', 'Contact Details', array( $this, 'output_meta_box' ), 'contact', 'normal', 'high' );   
	}

	/**
	* Halaman Detail kontak
	*
	* @param WP_Post $post WordPress Post object
	*/
	function output_meta_box( $post ) {
		$email = get_post_meta( $post->ID, '_contact_email', true );

		wp_nonce_field( 'save_contact', 'contacts_nonce' );

	   // Print label dan field
	  echo ( '<label for="contact_email">' . __( 'Email Address', 'yp-crm' ) . '</label>'  );
	  echo ( '<input type="text" name="contact_email" id="contact_email" value="' . esc_attr( $email ) . '" />'  );
	     
	}

	/**
	* Form field
	*
	* @param int $post_id Post ID
	*/
	function save_meta_boxes( $post_id ) {

    // Check if our nonce is set.
    if ( ! isset( $_POST['contacts_nonce'] ) ) {
        return $post_id;    
    }
 
    // Verify nonce
    if ( ! wp_verify_nonce( $_POST['contacts_nonce'], 'save_contact' ) ) {
        return $post_id;
    }

    // Check this is the Contact Custom Post Type
    if ( 'contact' != $_POST['post_type'] ) {
        return $post_id;
    }
 
    // Periksa user role
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return $post_id;
    }
 
    // Simpan
    $email = sanitize_text_field( $_POST['contact_email'] );
    update_post_meta( $post_id, '_contact_email', $email );
	     
	}
     
}
 
$YPSimpleCRM = new YPSimpleCRM;
register_activation_hook( __FILE__, array( &$YPSimpleCRM, 'plugin_activation' ) );
register_deactivation_hook( __FILE__, array( &$YPSimpleCRM, 'plugin_deactivation' ) );
